import { ShoppingAndRecipePage } from './app.po';

describe('shopping-and-recipe App', () => {
  let page: ShoppingAndRecipePage;

  beforeEach(() => {
    page = new ShoppingAndRecipePage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
