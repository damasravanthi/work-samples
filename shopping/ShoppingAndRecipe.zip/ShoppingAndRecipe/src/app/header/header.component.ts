
import {Component, EventEmitter, Output} from '@angular/core';

@Component({
  selector:'app-header',
  templateUrl:'./header.component.html'
})

export class HeaderComponent{
 @Output() clickedValue = new EventEmitter<string>();

  clicked(value: string){
  this.clickedValue.emit(value);
}
}
