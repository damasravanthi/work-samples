
import {NgModule} from "@angular/core";
import {RouterModule, Routes} from "@angular/router";
import { RecipesComponent } from './recipes/recipes.component';
import { RecipeStartComponent } from './recipes/recipe-start/recipe-start.component';
import { RecipeDetailComponent } from './recipes/recipe-detail/recipe-detail.component';
import { NewRecipeComponent } from './recipes/new-recipe/new-recipe.component';
import { ShoppingListComponent } from './shopping-list/shopping-list.component';
const routes : Routes=[
  {path: '', redirectTo: '/recipes',pathMatch:'full'},
  {path: 'recipes', component:RecipesComponent, children:[
    {path:'', component:RecipeStartComponent},
    {path: 'new', component:NewRecipeComponent },
    {path: 'edit', component:NewRecipeComponent },
    {path: ':id/edit', component:NewRecipeComponent },
    {path:':id', component:RecipeDetailComponent}

  ]},
  {path: 'shopping', component: ShoppingListComponent}
]
@NgModule({
imports:[RouterModule.forRoot(routes)],
  exports:[RouterModule]
})
export class AppRoutingModule{

}
