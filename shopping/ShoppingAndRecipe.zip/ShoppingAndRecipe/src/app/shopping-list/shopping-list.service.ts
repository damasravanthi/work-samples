import {Ingredient} from "../shared/ingredient.model";
import {Subject} from "rxjs/Subject";


export class ShoppingListService{

  private ingredients:Ingredient[] = [
    new Ingredient('Apples',5),
    new Ingredient('Bread',10)
  ];
  startedEditing = new Subject<Number>();
  getIngredients(){
    return this.ingredients;
  }
  getIngredient(index:number){
    return this.ingredients[index];
  }
  addIngredient(ingredient:Ingredient){
    this.ingredients.push(ingredient);

  }

  addIngredients(ingredients:Ingredient[]){
    for(let ingedient of ingredients){
      this.addIngredient(ingedient);
    }
  }
  updateIngredient(index : number, ingredient:Ingredient){
    this.ingredients[index]=ingredient;
  }
  deleteIngredient(index:number){
    this.ingredients.splice(index,1);
  }
}
