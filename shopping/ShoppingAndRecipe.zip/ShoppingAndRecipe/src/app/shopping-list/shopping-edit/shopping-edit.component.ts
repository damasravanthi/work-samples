import {Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {Ingredient} from "../../shared/ingredient.model";
import {ShoppingListService} from "../shopping-list.service";
import { NgForm} from "@angular/forms";
import {Subscription} from "rxjs/Subscription";

@Component({
  selector: 'app-shopping-edit',
  templateUrl: './shopping-edit.component.html',
  styleUrls: ['./shopping-edit.component.css']
})
export class ShoppingEditComponent implements OnInit, OnDestroy {
  @ViewChild('f') slForm: NgForm;
  subscription:Subscription;
  selectedIndex:number;
  editMode=false;
  editedItem : Ingredient;
  constructor(private shoppingListService:ShoppingListService) { }

  ngOnInit() {
  this.subscription = this.shoppingListService.startedEditing.subscribe(
    (index:number) =>{
      //console.log(index);
      this.selectedIndex = index;
      this.editMode = true;
      this.editedItem = this.shoppingListService.getIngredient(index);
      //console.log(this.editedItem);
      this.slForm.setValue({
        name: this.editedItem.name,
        amount: this.editedItem.amount

      })
    }
  );
  }

  add(form: NgForm){
    const data= form.value;
    const newIngredient:Ingredient = new Ingredient(data.name,data.amount);
    if(this.editMode === false ) {
      this.shoppingListService.addIngredient(newIngredient);
    }
    else{
      this.shoppingListService.updateIngredient(this.selectedIndex,newIngredient);
    }
    form.reset();
    this.editMode=false;
  }
  onClear(){
    this.slForm.reset();
    this.editMode=false;
  }
  onDelete(){
    this.shoppingListService.deleteIngredient(this.selectedIndex);
    this.onClear();
  }
  ngOnDestroy(){
    this.shoppingListService.startedEditing.unsubscribe();
  }

}
