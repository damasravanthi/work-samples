import {Recipe} from "./recipe.model";
import { Injectable} from "@angular/core";
import {Ingredient} from "../shared/ingredient.model";
import {ShoppingListService} from "../shopping-list/shopping-list.service";
@Injectable()
export class RecipeService {

  recipes: Recipe[] = [
    new Recipe('Biryani',
      'Super tasty in hyd',
      'https://upload.wikimedia.org/wikipedia/commons/7/7c/Hyderabadi_Chicken_Biryani.jpg',
    [
      new Ingredient('Rice',5),
      new Ingredient('Chicken', 10)
    ]),
    new Recipe('Biryani 2',
      'Super tasty 2',
      'https://upload.wikimedia.org/wikipedia/commons/7/7c/Hyderabadi_Chicken_Biryani.jpg',
      [
        new Ingredient('Basmathi',5),
        new Ingredient('Lamb', 10)
      ])
  ];
    constructor(private shoppingListService:ShoppingListService){

    }

    getById(id:number){
      return this.recipes[id];

    }
  getRecipes(){
    return this.recipes.slice();
  }

  addIngredientsToShoppingList(ingredients : Ingredient[]){
    this.shoppingListService.addIngredients(ingredients);

  }

}
