import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Params} from "@angular/router";
import {FormArray, FormControl, FormGroup} from "@angular/forms";
import {RecipeService} from "../recipe.service";
import {Recipe} from "../recipe.model";

@Component({
  selector: 'app-new-recipe',
  templateUrl: './new-recipe.component.html',
  styleUrls: ['./new-recipe.component.css']
})
export class NewRecipeComponent implements OnInit {
  id:number;
  editMode = false;
  recipeForm:FormGroup;
  constructor(private route:ActivatedRoute, private recipeService:RecipeService) { }

  ngOnInit() {
    this.route.params.subscribe(
      (params:Params)=>{
      this.id=+params['id'];
      this.editMode = params['id']!=null ;
      console.log(this.editMode);
      this.onFormInit();
    });
  }
  onAddIngredient(){
    (<FormArray>this.recipeForm.get('ingredients')).push(new FormGroup({
      'name':new FormControl,
      'amount':new FormControl
    }))
  }
  onSubmitted(){
    console.log(this.recipeForm);
  }
    private onFormInit(){

      let recipeName='';
      let recipeImgPath='';
      let recipeDescription='';
      let recipeIngredients = new FormArray([]);

      if (this.editMode){
        const recipe = this.recipeService.getById(this.id);
        recipeName=recipe.name;
        recipeImgPath=recipe.imagePath;
        recipeDescription=recipe.description;
        //console.log(recipe);
        if(recipe['ingredients']){
          for(let ingredient of recipe.ingredients){
            recipeIngredients.push(new FormGroup({
              'name':new FormControl(ingredient.name.slice()),
              'amount':new FormControl(ingredient.amount.valueOf())
            }));
          }
        }
      }
      this.recipeForm = new FormGroup({
        'name':new FormControl(recipeName),
        'imagePath':new FormControl(recipeImgPath),
        'description':new FormControl(recipeDescription),
        'ingredients':recipeIngredients
      });
    }
}
