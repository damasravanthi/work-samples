import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import {RecentTransactionComponent} from './recent-transaction/recent-transaction.component'
import { TransferComponent } from './tranfer/transfer.component';
import {Header} from './header/header.component';
import {TransactionService} from './../services/transactions.service';

@NgModule({
  declarations: [
    AppComponent,
    RecentTransactionComponent,
    TransferComponent,
    Header
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule
  ],
  providers: [TransactionService],
  bootstrap: [AppComponent]
})
export class AppModule { }
