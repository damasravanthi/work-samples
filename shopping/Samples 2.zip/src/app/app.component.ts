import { Component} from '@angular/core';
// import { TransactionService } from '../services/transactions.service';
import { TransferComponent } from '../app/tranfer/transfer.component';
import {RecentTransactionComponent} from '../app/recent-transaction/recent-transaction.component'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
}
