import { Component, OnInit } from '@angular/core';
import { TransactionService } from './../../services/transactions.service'

@Component({
  selector: 'app-recent-transaction',
  templateUrl: './recent-transaction.component.html',
  styleUrls: ['./recent-transaction.component.css']
})
export class RecentTransactionComponent {
    transactions=[];
    currenttransaction;
    constructor(
    private _TransactionService:TransactionService){}
    ngOnInit(){
        this._TransactionService.getRecentTransactions().then((result)=>{
            this.transactions = result; 
        });
        this._TransactionService.currentTransaction.subscribe((transaction) => {
            this.currenttransaction = transaction;
            this.transactions.unshift(this.currenttransaction)
        });
    }
}
